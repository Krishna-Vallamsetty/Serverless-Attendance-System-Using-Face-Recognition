const { RekognitionClient, SearchFacesByImageCommand } = require("@aws-sdk/client-rekognition");
const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

const rekognition = new RekognitionClient({ region: "ap-south-1" });
const dynamodb = new DynamoDBClient({ region: "ap-south-1" });

exports.handler = async (event) => {
    console.log("Event received:", JSON.stringify(event, null, 2));

    const bucket = event.bucket;
    const key = event.key;

    if (!bucket || !key) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: "Missing bucket or key in event" })
        };
    }

    try {
        // Step 1: Search for a face in the Rekognition collection
        const searchCommand = new SearchFacesByImageCommand({
            CollectionId: "your-collection-id", // <-- Change this to your collection
            Image: {
                S3Object: {
                    Bucket: bucket,
                    Name: key
                }
            },
            MaxFaces: 1,
            FaceMatchThreshold: 90
        });

        const rekogResult = await rekognition.send(searchCommand);
        console.log("Rekognition search result:", rekogResult);

        if (!rekogResult.FaceMatches || rekogResult.FaceMatches.length === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: "No matching face found" })
            };
        }

        const matchedFace = rekogResult.FaceMatches[0].Face;
        console.log("Matched Face:", matchedFace);

        // Step 2: Store attendance in DynamoDB
        const putCommand = new PutItemCommand({
            TableName: "YourDynamoDBTable", // <-- Change to your DynamoDB table
            Item: {
                FaceId: { S: matchedFace.FaceId },
                Timestamp: { S: new Date().toISOString() },
                ImageKey: { S: key }
            }
        });

        await dynamodb.send(putCommand);
        console.log("Attendance saved to DynamoDB");

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Attendance recorded", matchedFace })
        };

    } catch (error) {
        console.error("Error processing image:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error processing image", error: error.message })
        };
    }
};
