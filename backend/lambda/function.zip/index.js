// index.js - ES Module Lambda handler for AttendanceProcessor
import AWS from 'aws-sdk';

const s3 = new AWS.S3();
const rekognition = new AWS.Rekognition();
const dynamodb = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  console.log("Incoming event:", JSON.stringify(event, null, 2));
  try {
    let body = event.body ? JSON.parse(event.body) : event;
    const { imageKey } = body;
    if (!imageKey) {
      throw new Error("Missing required parameter: imageKey");
    }

    const bucketName = process.env.BUCKET_NAME;
    const collectionId = process.env.COLLECTION_ID;
    const tableName = process.env.DYNAMODB_TABLE;

    console.log(`Processing ${imageKey} from bucket ${bucketName}`);

    // Retrieve image from S3
    const image = await s3.getObject({ Bucket: bucketName, Key: imageKey }).promise();
    console.log(`Downloaded image from S3. Size: ${image.Body.length} bytes`);

    // Search for matching face using Rekognition
    const searchResult = await rekognition.searchFacesByImage({
      CollectionId: collectionId,
      Image: { Bytes: image.Body },
      MaxFaces: 1,
      FaceMatchThreshold: 90
    }).promise();
    console.log("Rekognition search result:", JSON.stringify(searchResult, null, 2));

    if (!searchResult.FaceMatches || searchResult.FaceMatches.length === 0) {
      return response(200, { message: "No matching face found" });
    }

    const match = searchResult.FaceMatches[0];
    const employeeId = match.Face.ExternalImageId;
    console.log(`Matched EmployeeID: ${employeeId}`);

    // Use date yyyy-mm-dd as timestamp key to avoid duplicates in a day
    const today = new Date().toISOString().split("T")[0];

    // Check if attendance already marked today for this employee
    const existing = await dynamodb.get({
      TableName: tableName,
      Key: { EmployeeID: employeeId, Timestamp: today }
    }).promise();

    if (existing.Item) {
      console.log(`Attendance already marked for ${employeeId} today`);
      return response(200, { message: `Attendance already marked for ${employeeId}` });
    }

    // Mark attendance in DynamoDB
    await dynamodb.put({
      TableName: tableName,
      Item: { EmployeeID: employeeId, Timestamp: today }
    }).promise();

    console.log(`Attendance recorded for ${employeeId} at ${today}`);
    return response(200, { message: `Attendance marked for ${employeeId}` });
  } catch (err) {
    console.error("Error processing attendance:", err);
    return response(500, { error: err.message || "Internal server error" });
  }
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}
