const AWS = require('aws-sdk');
const rekognition = new AWS.Rekognition();
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    console.log("Event:", event);

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    };

    if (!event.body) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: "Missing request body" })
      };
    }

    const body = JSON.parse(event.body);

    if (!body.imageKey) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: "Missing 'imageKey'" })
      };
    }

    const rekogParams = {
      CollectionId: process.env.COLLECTION_ID,
      Image: {
        S3Object: {
          Bucket: "my-attendance-bucket-admin925",
          Name: body.imageKey
        }
      }
    };

    const match = await rekognition.searchFacesByImage(rekogParams).promise();
    console.log("Match:", match);

    const employeeId = match.FaceMatches.length > 0
      ? match.FaceMatches[0].Face.ExternalImageId
      : null;

    if (!employeeId) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: "No matching employee found" })
      };
    }

    const putParams = {
      TableName: process.env.DYNAMODB_TABLE,
      Item: {
        EmployeeID: employeeId,
        Timestamp: new Date().toISOString(),
        Matches: match.FaceMatches
      }
    };

    await dynamodb.put(putParams).promise();

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: "Attendance marked",
        employeeId,
        matchCount: match.FaceMatches.length
      })
    };

  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
      },
      body: JSON.stringify({
        message: "Error processing attendance",
        error: error.message
      })
    };
  }
};
